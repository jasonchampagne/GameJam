#pragma once
#include "Map/Map.hpp"

class Movable {
    public:
    virtual ~Movable() = default;
    virtual void move(Map &map) = 0;
};

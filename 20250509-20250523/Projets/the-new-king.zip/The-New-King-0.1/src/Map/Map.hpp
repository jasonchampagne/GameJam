#pragma once
#include <vector>
#include "../SDL3pp/SDL3pp.hpp"
#include <SDL3/SDL_rect.h>
#include <SDL3/SDL_render.h>
#include "../Displayable.hpp"

class Map
 : public Displayable
{
    public:
    Map() = default;
    Map(SDL_Renderer* renderer);
    Map(Map const&) = delete;
    Map& operator=(Map const&) = delete;
    Map(Map&&) = default;
    Map& operator=(Map &&) = default;
    ~Map() = default;

    float get_left_camera_pos() const noexcept {
        return m_camera_view.x;
    }
    float get_right_camera_pos() const noexcept {
        return m_camera_view.x + (m_camera_view.w*PIXEL_BY_REAL_PIXEL);
    }
    float get_top_camera_pos() const noexcept {
        return m_camera_view.y;
    }
    float get_bottom_camera_pos() const noexcept {
        return m_camera_view.y + (m_camera_view.h*PIXEL_BY_REAL_PIXEL);
    }

    float get_camera_width() const noexcept {
        return m_camera_view.w*PIXEL_BY_REAL_PIXEL;
    }

    float get_camera_height() const noexcept {
        return m_camera_view.h*PIXEL_BY_REAL_PIXEL;
    }

    SDL_FPoint get_map_size() const noexcept {
        SDL_FPoint size;
        SDL_GetTextureSize(
            const_cast<SDL_Texture*>(
                static_cast<SDL_Texture const*>(m_texture)),
            &size.x, &size.y);
        size.x*=PIXEL_BY_REAL_PIXEL;
        size.y*=PIXEL_BY_REAL_PIXEL;
        return size;
    }

    SDL_FPoint get_camera_size() const noexcept {
        return SDL_FPoint{CAMERA_VIEW_WIDTH, CAMERA_VIEW_HEIGHT};
    }

    /**
     * @brief Move camera on X axe, return effective move réalise, because if camera touch edge his don't finish move, return no applied move
     */
    float move_x_camera(float movement) noexcept;

    float move_y_camera(float movement) noexcept;

    void draw(SDL_Renderer* renderer) override;

    constexpr float get_pixel_by_pixel_real() const noexcept {
        return PIXEL_BY_REAL_PIXEL;
    }

    private:
    SDL3pp::Texture m_texture;
    SDL_FRect m_camera_view;
    std::vector<std::vector<bool>> m_collide_box;
    static constexpr float CAMERA_VIEW_WIDTH {800};
    static constexpr float CAMERA_VIEW_HEIGHT {800};
    static constexpr float PIXEL_BY_REAL_PIXEL {15.f};
    static constexpr float CAMERA_REAL_WIDTH { CAMERA_VIEW_WIDTH/PIXEL_BY_REAL_PIXEL};
    static constexpr float CAMERA_REAL_HEIGHT {CAMERA_VIEW_HEIGHT/PIXEL_BY_REAL_PIXEL};
};

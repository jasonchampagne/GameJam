#include <SDL3/SDL_error.h>
#include <SDL3/SDL_oldnames.h>
#include <SDL3/SDL_rect.h>
#include <SDL3/SDL_render.h>
#include <SDL3/SDL_surface.h>
#include <SDL3_image/SDL_image.h>
#include <stdexcept>
#include "Map.hpp"

Map::Map(SDL_Renderer* renderer)
: m_camera_view{6000.f, 6000.f, CAMERA_REAL_WIDTH, CAMERA_REAL_HEIGHT}
{
    m_texture = IMG_LoadTexture(renderer, "assets/map.png");
    SDL_SetTextureScaleMode(m_texture, SDL_SCALEMODE_NEAREST);
    if (!m_texture) {
        throw std::runtime_error(SDL_GetError());
    }
}

float Map::move_x_camera(float movement) noexcept {
    float new_pos {m_camera_view.x + movement};
    if (new_pos < 0) {
        m_camera_view.x = 0;
        return new_pos;
    }
    float max_x {get_map_size().x - CAMERA_VIEW_WIDTH};
    if (new_pos > max_x) {
        m_camera_view.x = max_x;
        return new_pos - max_x;
    }

    m_camera_view.x += movement;
    return 0;
}

float Map::move_y_camera(float movement) noexcept {
    float new_pos {m_camera_view.y + movement};
    if (new_pos < 0) {
        m_camera_view.y = 0;
        return new_pos;
    }
    float max_y {get_map_size().y - CAMERA_VIEW_HEIGHT};
    if (new_pos > max_y) {
        m_camera_view.y = max_y;
        return new_pos - max_y;
    }

    m_camera_view.y += movement;
    return 0;
}

void Map::draw(SDL_Renderer* renderer)
{
    SDL_FRect src{m_camera_view.x/PIXEL_BY_REAL_PIXEL, m_camera_view.y/PIXEL_BY_REAL_PIXEL, CAMERA_REAL_WIDTH, CAMERA_REAL_HEIGHT};
    SDL_FRect dst {0.f, 0.f, CAMERA_VIEW_WIDTH, CAMERA_VIEW_HEIGHT};
    SDL_RenderTexture(renderer, m_texture, &src, &dst);
}

#include <SDL3/SDL_render.h>
#include <SDL3/SDL_rect.h>
#include <SDL3/SDL_timer.h>
#include <stdexcept>
#include "SpriteSeries.hpp"


void SpriteSeries::set_current_track(unsigned int track_number) {
    if (track_number < m_number_track) {
        reset();
        m_current_track = track_number;
        m_rect_sprite.y = static_cast<float>(m_current_track)*m_rect_sprite.h;
    }
    else
        throw std::invalid_argument("Track number");
}

unsigned int SpriteSeries::get_current_track() const {
    return m_current_track;
}

void SpriteSeries::draw(SDL_Renderer* renderer, SDL_FRect const& dst_rect) {
    if (!SDL_RenderTexture(renderer, m_texture, &m_rect_sprite, &dst_rect)) {
        throw std::runtime_error(SDL_GetError());
    }
    if (SDL_GetTicks() >= m_last_change + m_time_between)
    {
        m_last_change = SDL_GetTicks();
        if (m_current_sprite+1 >= m_number_sprite[m_current_track]) {
            m_current_sprite = 0;
            m_rect_sprite.x = 0;
        }
        else {
            ++m_current_sprite;
            m_rect_sprite.x += m_rect_sprite.w;
        }
    }
}

void SpriteSeries::reset() noexcept {
    m_last_change = SDL_GetTicks();
    m_current_sprite = 0;
    m_rect_sprite.x = 0;
}

#pragma once
#include <SDL3/SDL_stdinc.h>
#include <cassert>
#include <initializer_list>
#include <vector>
#include <SDL3/SDL_render.h>
#include <SDL3/SDL_rect.h>

class SpriteSeries {
    public:
    SpriteSeries() = default;
    SpriteSeries(SDL_Texture const* texture,
                 float widthSprite,
                 float heightSprite,
                 unsigned int number_track,
                 std::initializer_list<unsigned int> number_sprite,
                 Uint64 time_between_sprite)
     : m_current_sprite(0),
       m_number_sprite(number_sprite),
       m_current_track(0),
       m_number_track(number_track),
       m_time_between(time_between_sprite),
       m_last_change(0),
       m_texture(const_cast<SDL_Texture*>(texture)),
       m_rect_sprite{0.f, 0.f, widthSprite, heightSprite}
    {
        assert(static_cast<unsigned int>(std::size(number_sprite)) == number_track);
    }

    SpriteSeries(SpriteSeries const&) = delete;
    SpriteSeries& operator=(SpriteSeries const&) = delete;
    SpriteSeries(SpriteSeries&&) noexcept = default;
    SpriteSeries& operator=(SpriteSeries&&) noexcept = default;

    void set_current_track(unsigned int track_number);
    unsigned int get_current_track() const;
    void draw(SDL_Renderer* renderer, SDL_FRect const& dst_rect);
    void reset() noexcept;

    private:
    unsigned int m_current_sprite;
    std::vector<unsigned int> m_number_sprite;
    unsigned int m_current_track;
    unsigned int m_number_track;
    Uint64 m_time_between;
    Uint64 m_last_change;
    SDL_Texture* m_texture;
    SDL_FRect m_rect_sprite;
};

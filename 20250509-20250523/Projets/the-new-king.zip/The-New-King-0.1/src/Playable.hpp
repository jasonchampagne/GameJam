#pragma once
#include <SDL3/SDL_events.h>
#include "ScanMap.hpp"

class Playable {
    public:
    virtual ~Playable() = default;
    virtual void read_input(ScanMap const& scan) = 0;
};

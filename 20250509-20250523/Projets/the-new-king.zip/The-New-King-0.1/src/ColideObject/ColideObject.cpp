#include <SDL3/SDL_oldnames.h>
#include <SDL3/SDL_rect.h>
#include "ColideObject.hpp"

ColideObject::ColideObject(float x, float y, float w, float h)
 : m_collide_box{x, y, w, h}
{
}

ColideObject::ColideObject(SDL_FRect const& collide_box)
 : m_collide_box(collide_box)
{
}

bool ColideObject::collide(ColideObject const& other) const
{
    SDL_FRect tmp;
    return SDL_GetRectIntersectionFloat(&m_collide_box, &other.m_collide_box, &tmp);
}

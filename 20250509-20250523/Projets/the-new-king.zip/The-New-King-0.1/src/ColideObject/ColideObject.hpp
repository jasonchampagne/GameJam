#pragma once

#include <SDL3/SDL_rect.h>
class ColideObject
{
    public:
    ColideObject(float x, float y, float w, float h);
    ColideObject(SDL_FRect const& collide_box);

    bool collide(ColideObject const& other) const;

    private:
    SDL_FRect m_collide_box;
};

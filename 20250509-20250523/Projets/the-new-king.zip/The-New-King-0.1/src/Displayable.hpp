#pragma once
#include <SDL3/SDL_render.h>

class Displayable {
    public:
    virtual ~Displayable() = default;
    virtual void draw(SDL_Renderer* renderer) = 0;
};

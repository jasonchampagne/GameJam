
#include "SDL3_mixer/SDL_mixer.h"
#include <SDL3/SDL_audio.h>
#include <SDL3/SDL_error.h>
#include <SDL3/SDL_oldnames.h>
#define SDL_MAIN_USE_CALLBACKS
#include <SDL3/SDL_main.h>
#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3/SDL_init.h>
#include <SDL3/SDL_scancode.h>
#include <SDL3/SDL_stdinc.h>
#include <SDL3/SDL_timer.h>
#include <SDL3/SDL_events.h>
#include <SDL3/SDL_keycode.h>
#include <SDL3/SDL_rect.h>
#include <SDL3/SDL_render.h>
#include "SDL3pp/SDL3pp.hpp"
#include "Player/Player.hpp"
#include "ScanMap.hpp"

#include <iostream>

namespace {
    constexpr Uint64 FRAMERATE_LIMIT = 16; // 16 ms = 60 fps
}

struct App
{
    SDL3pp::Window window;
    SDL3pp::Renderer renderer;
    SDL3pp::Music music;
    SDL_AudioSpec spec;
    Player player;
    ScanMap scanMap;
    Uint64 refreshTime;
    Map map;
};

SDL_AppResult SDL_AppInit(void **appstate, int, char **)
{
    *appstate = new App;
    App *app = static_cast<App *>(*appstate);

    if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO))
    {
        return SDL_APP_FAILURE;
    }
    Mix_Init(MIX_INIT_MP3);

    SDL_Window* tmp_window;
    SDL_Renderer* tmp_renderer;
    if (!SDL_CreateWindowAndRenderer("The new king", 800, 800, 0, &tmp_window, &tmp_renderer))
    {
        return SDL_APP_FAILURE;
    }
    app->window = tmp_window;
    app->renderer = tmp_renderer;

    SDL3pp::Surface tmp_surface {IMG_Load("assets/test.png")};

   app->spec.freq = 44100;
   app->spec.format = SDL_AUDIO_S16;
   app->spec.channels = 2;

    if (!Mix_OpenAudio(0, &app->spec)) {
        std::cerr << "Mix_OpenAudio Error: " << SDL_GetError() << std::endl;
        return SDL_APP_FAILURE;
    }

    app->music = Mix_LoadMUS("assets/music.mp3");
    if (app->music == nullptr) {
        std::cout << SDL_GetError() << std::endl;
    }
    Mix_PlayMusic(app->music, -1);
    Mix_VolumeMusic(75);
    app->map = Map(app->renderer);
    app->player = Player(app->map, app->renderer);
    app->refreshTime = 0;
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppIterate(void *appstate)
{
    App *app = static_cast<App *>(appstate);
    Uint64 delta = SDL_GetTicks() - app->refreshTime;
    if (delta < FRAMERATE_LIMIT)
    {
        SDL_Delay(static_cast<Uint32>(FRAMERATE_LIMIT - delta));
    }
    app->refreshTime = SDL_GetTicks();


    SDL_RenderClear(app->renderer);
    app->map.draw(app->renderer);
    app->player.move(app->map);
    app->player.draw(app->renderer);
    SDL_RenderPresent(app->renderer);
    return SDL_APP_CONTINUE;
}

SDL_AppResult SDL_AppEvent(void *appstate, SDL_Event *event)
{
    App *app = static_cast<App *>(appstate);
    switch (event->type) {
    case SDL_EVENT_QUIT:
        return SDL_APP_SUCCESS;
        break;
    case SDL_EVENT_KEY_DOWN:
        if (event->key.scancode == SDL_SCANCODE_ESCAPE) {
            return SDL_APP_FAILURE;
        }
        app->scanMap.set(event->key.scancode, true);
        break;
    case SDL_EVENT_KEY_UP:
        app->scanMap.set(event->key.scancode, false);
        break;
    default:
        break;
    }
    app->player.read_input(app->scanMap);
    return SDL_APP_CONTINUE;
}

void SDL_AppQuit(void *appstate, SDL_AppResult)
{
    delete static_cast<App*>(appstate);
    Mix_CloseAudio();
    Mix_Quit();
    SDL_Quit();
}

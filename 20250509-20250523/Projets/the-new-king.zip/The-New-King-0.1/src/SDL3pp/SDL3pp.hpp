#pragma once
#include "SDL3_mixer/SDL_mixer.h"
#include <SDL3/SDL.h>
#include <SDL3/SDL_oldnames.h>
#include <SDL3/SDL_render.h>
#include <SDL3/SDL_surface.h>
#include <utility>
#include <memory>

namespace SDL3pp {

    template<typename T, void(*DESTRUCTOR)(T*) >
    class SDL_Wrapper
    {
    public:
        SDL_Wrapper(T *ptr = nullptr) : m_ptr(ptr)
        {
        }

        SDL_Wrapper(const SDL_Wrapper &) = delete;
        SDL_Wrapper& operator=(const SDL_Wrapper &) = delete;

        SDL_Wrapper(SDL_Wrapper &&ptr) noexcept : m_ptr(ptr)
        {
            ptr.m_ptr = nullptr;
        }

        SDL_Wrapper &operator=(SDL_Wrapper &&ptr) noexcept
        {
            std::swap(m_ptr, ptr.m_ptr);
            return *this;
        }

        ~SDL_Wrapper() {
            if (m_ptr != nullptr)
            {
                DESTRUCTOR(m_ptr);
            }
            m_ptr = nullptr;
        }

        T *get()
        {
            return m_ptr;
        }

        const T *get() const
        {
            return m_ptr;
        }

        operator T *()
        {
            return m_ptr;
        }

        operator const T *() const
        {
            return m_ptr;
        }

        T *operator->()
        {
            return m_ptr;
        }

        const T *operator->() const
        {
            return m_ptr;
        }

    private:
        T *m_ptr;

    };

    using Window = SDL_Wrapper<SDL_Window, SDL_DestroyWindow>;
    using Renderer = SDL_Wrapper<SDL_Renderer, SDL_DestroyRenderer>;
    using Texture = SDL_Wrapper<SDL_Texture, SDL_DestroyTexture>;
    using Surface = SDL_Wrapper<SDL_Surface, SDL_DestroySurface>;
    using Music = SDL_Wrapper<Mix_Music, Mix_FreeMusic>;
}

#pragma once

enum Direction {
    NO_DIRECTION,
    UP,
    DOWN,
    LEFT,
    RIGHT,
};

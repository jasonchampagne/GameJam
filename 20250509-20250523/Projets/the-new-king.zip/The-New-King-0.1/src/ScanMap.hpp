#pragma once
#include <SDL3/SDL_scancode.h>
#include <vector>

class ScanMap {
    public:
    ScanMap()
    : m_scan(SDL_SCANCODE_COUNT, false){};
    ScanMap(ScanMap const&) = default;
    ScanMap& operator=(ScanMap const&) = default;
    ScanMap(ScanMap&&) = default;
    ScanMap& operator=(ScanMap&&) = default;

    bool get(SDL_Scancode scan) const {
        return m_scan[scan];
    }

    void set(SDL_Scancode scan, bool state) {
        m_scan[scan] = state;
    }
    private:
    std::vector<bool> m_scan;
};

#pragma once

#include "../SDL3pp/SDL3pp.hpp"
#include "../SpriteSeries/SpriteSeries.hpp"
#include "../Displayable.hpp"
// #include "../Storable.hpp"
#include "../Playable.hpp"
#include "../Movable.hpp"
#include "../ScanMap.hpp"
#include "../Map/Map.hpp"
#include "../ColideObject/ColideObject.hpp"
#include <SDL3/SDL_events.h>
#include <SDL3/SDL_rect.h>
#include <SDL3/SDL_render.h>
#include <SDL3/SDL_stdinc.h>
#include <array>


class Player final
 : public ColideObject,
   public Displayable,
   // public Storable,
   public Playable,
   public Movable
{
public:
    Player() = default;
    Player(Map& map, SDL_Renderer* renderer);
    Player(Player const&) = delete;
    Player& operator=(Player const&) = delete;
    Player(Player&&) = default;
    Player& operator=(Player&&) = default;

    ~Player() = default;

    void draw(SDL_Renderer* renderer) override;
    void read_input(ScanMap const& scan) override;
    void move(Map& map) override;
private:
    void updateSpriteTrack();

    SDL3pp::Texture m_texture;
    SpriteSeries m_sprites;
    SDL_FPoint m_pos_player;
    SDL_FPoint m_pos_player_map;
    float m_velocity;
    Uint64 m_last_move;
    SDL_FPoint m_current_direction;
    std::array<bool, 4> m_pressed_button;

    static constexpr float SPRITE_WIDTH = 100.f;
    static constexpr float SPRITE_HEIGHT = 100.f;
    static constexpr float SPRITE_RATIO_UPSCALE = 1.5f;
    static constexpr float DISPLAY_SPRITE_WIDTH = SPRITE_WIDTH*SPRITE_RATIO_UPSCALE;
    static constexpr float DISPLAY_SPRITE_HEIGHT = SPRITE_HEIGHT*SPRITE_RATIO_UPSCALE;
};

#include "Player.hpp"
#include "../Map/Map.hpp"
#include <SDL3/SDL_events.h>
#include <SDL3/SDL_keycode.h>
#include <SDL3/SDL_render.h>
#include <SDL3/SDL_scancode.h>
#include <SDL3/SDL_stdinc.h>
#include <SDL3/SDL_surface.h>
#include <SDL3/SDL_timer.h>
#include <SDL3_image/SDL_image.h>
#include <ctime>
#include <numbers>
#include <cmath>

#include <iostream>


#define CLOCKS_PER_MILLISEC (CLOCKS_PER_SEC / 1000)

Player::Player(Map& map, SDL_Renderer* renderer)
: m_texture(), m_sprites(),
  m_pos_player{
      map.get_camera_width()/2-DISPLAY_SPRITE_WIDTH/2.f,
      map.get_camera_height()/2-DISPLAY_SPRITE_HEIGHT/2.f
  },
  m_pos_player_map{
      map.get_left_camera_pos() + map.get_camera_width()/2-DISPLAY_SPRITE_WIDTH/2.f,
      map.get_top_camera_pos() + map.get_camera_height()/2-DISPLAY_SPRITE_HEIGHT/2.f},
  m_velocity(300),
  m_last_move(0),
  m_current_direction{0.f, 0.f}
{
    m_texture = IMG_LoadTexture(renderer, "assets/player.png");
    SDL_SetTextureScaleMode(m_texture, SDL_SCALEMODE_NEAREST);

    m_sprites = SpriteSeries(
        m_texture,
        SPRITE_WIDTH,
        SPRITE_HEIGHT,
        5u,
        {3u, 3u, 3u, 3u, 3u},
        250);
}

void Player::draw(SDL_Renderer* renderer) {
    SDL_FRect dst {
        m_pos_player.x,
        m_pos_player.y,
        DISPLAY_SPRITE_WIDTH, DISPLAY_SPRITE_WIDTH
    };
    m_sprites.draw(renderer, dst);
}

void Player::read_input(ScanMap const& scan) {
    float last_x=m_current_direction.x, last_y=m_current_direction.y;
    m_current_direction.x = 0.f;
    m_current_direction.y = 0.f;
    if (scan.get(SDL_SCANCODE_W))
        --m_current_direction.y;
    if (scan.get(SDL_SCANCODE_S))
        ++m_current_direction.y;
    if (scan.get(SDL_SCANCODE_A))
        --m_current_direction.x;
    if (scan.get(SDL_SCANCODE_D))
        ++m_current_direction.x;

    if (last_x != m_current_direction.x || last_y != m_current_direction.y)
    {
        updateSpriteTrack();
    }
}

void Player::updateSpriteTrack() {
    if (m_current_direction.y > 0) {
        m_sprites.set_current_track(3u);
    }
    else if (m_current_direction.y < 0) {
        m_sprites.set_current_track(4u);
    }
    else if (m_current_direction.x > 0) {
        m_sprites.set_current_track(1u);
    }
    else if (m_current_direction.x < 0) {
        m_sprites.set_current_track(2u);
    }
    else {
        m_sprites.set_current_track(0u);
    }
}

void Player::move(Map& map) {
    float delay {static_cast<float>(SDL_GetTicks()-m_last_move)/1000.f};
    m_last_move = SDL_GetTicks();
    float speed {m_velocity*delay};

    float center_pos_player_y {m_pos_player_map.y + DISPLAY_SPRITE_HEIGHT/2.f};
    float center_pos_player_x {m_pos_player_map.x + DISPLAY_SPRITE_WIDTH/2.f};

    if (m_current_direction.x != 0 || m_current_direction.y != 0) {
        if (m_current_direction.x == 0) {
            float dep {m_current_direction.y*speed};
            if ( center_pos_player_y >= map.get_camera_size().y/2
                && center_pos_player_y <= map.get_map_size().y - map.get_camera_size().y/2) {
                m_pos_player_map.y += dep;
                map.move_y_camera(dep);
            }
            else {
                m_pos_player_map.y += dep;
                m_pos_player.y += dep;

            }
        }
        else if (m_current_direction.y == 0) {
            float dep {m_current_direction.x*speed};
            if (center_pos_player_x >= map.get_camera_size().x/2
                && center_pos_player_x <= map.get_map_size().x - map.get_camera_size().x/2) {
                m_pos_player_map.x += dep;
                map.move_x_camera(dep);
            }
            else {
                m_pos_player_map.x += dep;
                m_pos_player.x += dep;
            }
        }
        else {
            constexpr float _1_sqrt2_v {1.f/std::numbers::sqrt2_v<float>};
            float depx {m_current_direction.x*speed*std::abs(m_current_direction.y)*_1_sqrt2_v};
            float depy {m_current_direction.y*speed*std::abs(m_current_direction.x)*_1_sqrt2_v};

            if (center_pos_player_x >= map.get_camera_size().x/2
                && center_pos_player_x <= map.get_map_size().x - map.get_camera_size().x/2) {
                m_pos_player_map.x += depx;
                map.move_x_camera(depx);
            }
            else {
                m_pos_player_map.x += depx;
                m_pos_player.x += depx;
            }
            if (center_pos_player_y >= map.get_camera_size().y/2
                && center_pos_player_y <= map.get_map_size().y - map.get_camera_size().y/2) {
                m_pos_player_map.y += depy;
                map.move_y_camera(depy);
            }
            else {
                m_pos_player_map.y += depy;
                m_pos_player.y += depy;
            }
        }
    }
}

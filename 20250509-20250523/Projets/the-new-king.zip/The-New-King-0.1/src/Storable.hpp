#pragma once
#include <ostream>

class Storable {
    public:
    virtual ~Storable() = default;
    virtual void writeSave(std::ostream& os) = 0;
    virtual void readSave(std::istream& is) = 0;
};

#!/usr/bin/sh

mkdir librairies
git clone https://github.com/libsdl-org/SDL.git libraries/SDL
git clone https://github.com/libsdl-org/SDL_ttf.git libraries/SDL_ttf
git clone https://github.com/libsdl-org/SDL_image.git libraries/SDL_image
git clone https://github.com/libsdl-org/SDL_mixer.git libraries/SDL_mixer